package com.cg.springmvcpractice.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.springmvcpractice.dto.Mobile;
@Repository("mobiledao")
public class IMobileDaoImpl implements IMobileDao {
	
	@PersistenceContext  //to link in dispatch
	EntityManager em;

	@Override
	public void addMobile(Mobile mobile) {
		// TODO Auto-generated method stub
	em.persist(mobile);  //toSava Data in db
	em.flush();
	}

	@Override
	public List<Mobile> showAllMobile() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteMobile(int mobId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Mobile searchMobile(int mobId) {
		// TODO Auto-generated method stub
		return null;
	}

}
