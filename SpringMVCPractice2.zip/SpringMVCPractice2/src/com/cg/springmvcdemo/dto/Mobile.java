package com.cg.springmvcdemo.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;




@Entity
@Table(name="mobileonedata")
public class Mobile {
	
	@Id
	@Column(name="mob_id")
	@NotNull(message= "Mobile Id cannot be empty")
	Integer mobId;
	@Column(name="mob_name")
	@NotEmpty(message="name cannot be empty")//wrapper class
	String mobName;
	@Column(name="mob_price")
	@NotNull(message="price cannot be empty")
	Double mobPrice;
	@Column(name="mob_cato")
	//@NotEmpty(message="category has to be selected")
	String mobCategory;
	@Column(name="mob_online")
	//@NotEmpty(message="select yes or no")
	String onlineAvailable;
	
	public String getOnlineAvailable() {
		return onlineAvailable;
	}


	public void setOnlineAvailable(String onlineAvailable) {
		this.onlineAvailable = onlineAvailable;
	}


	public Mobile() {
		// TODO Auto-generated constructor stub
	}
	
	
	public Mobile(Integer mobId, String mobName, Double mobPrice,
			String mobCategory,String onlineAvailable) {
		super();
		this.mobId = mobId;
		this.mobName = mobName;
		this.mobPrice = mobPrice;
		this.mobCategory = mobCategory;
		this.onlineAvailable = onlineAvailable;
		
	}




	public Integer getMobId() {
		return mobId;
	}
	public void setMobId(Integer mobId) {
		this.mobId = mobId;
	}
	public String getMobName() {
		return mobName;
	}
	public void setMobName(String mobName) {
		this.mobName = mobName;
	}
	public Double getMobPrice() {
		return mobPrice;
	}
	public void setMobPrice(Double mobPrice) {
		this.mobPrice = mobPrice;
	}
	public String getMobCategory() {
		return mobCategory;
	}
	public void setMobCategory(String mobCategory) {
		this.mobCategory = mobCategory;
	}
	
	
	@Override
	public String toString() {
		return "Mobile [mobId=" + mobId + ", mobName=" + mobName
				+ ", mobPrice=" + mobPrice + ", mobCategory=" + mobCategory
				+ "]";
		}
}
