package com.cg.springrestful.service;

import java.util.List;

import com.cg.springrestful.dto.Mobile;

public interface IMobileService {
	
	public List<Mobile>getAllData();
}
